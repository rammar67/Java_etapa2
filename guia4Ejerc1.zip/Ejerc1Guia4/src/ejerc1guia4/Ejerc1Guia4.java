
 
package ejerc1guia4;
import java.util.Scanner;
/**
 *
 * @author luvac1422
 */
public class Ejerc1Guia4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("ingrese los numeros");
        Scanner leer=new Scanner(System.in);
        int num1 , num2;
        num1=leer.nextInt();
        num2=leer.nextInt();
        int opcion;
        float resultado=0;
        do {            
            System.out.println("1: sumar");
            System.out.println("2: restar");
            System.out.println("3: multiplicar");
            System.out.println("4 dividir");
            opcion=leer.nextInt();
            switch (opcion) {
                case 1: 
                resultado=sumar(num1,num2);
                    break;
                case 2:
                    resultado=restar(num1,num2);
                    break;
                case 3: 
                    resultado=multiplicar(num1,num2);
                    break;
                case 4:
                    resultado=dividir(num1,num2);
                    break;
                default:
                    
            }
            System.out.println("resultado="+ resultado);
        } while (true);
         
                   
        }
   
     public static float sumar(int num1, int num2) {
        return num1+num2;
    }
     public static float restar(int num1, int num2) {
        return num1-num2;
     } 
     public static float multiplicar(int num1, int num2) {
        return (num1*num2);
     }
     public static float dividir(int num1, int num2) {
        return (num1/num2);
    
    

